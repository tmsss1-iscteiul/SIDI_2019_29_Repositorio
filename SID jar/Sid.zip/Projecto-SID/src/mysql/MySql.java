package mysql;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.DefaultListModel;
import javax.swing.JList;

import org.bson.Document;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mongodb.client.MongoCursor;

import functionalities.Frame;
import mongo.Mongo;


public class MySql extends Thread{
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; // MySql driver

	static String DB_URL = null; 

	// Credenciais (username e password) de acesso ao Sybase
	
	static final String USER = "root";
	static final String PASS = "";
	//---
	
	private Connection conn = null;
    private Statement stmt = null;
    
	private Frame frame;

	// Modelo e lista para inserir posteriormente no scrollPane
	
	private DefaultListModel<String> model = new DefaultListModel<>();
	private JList<String> list;
	
	private boolean connect = false;
	
	private Mongo mongo;

	public MySql(Frame frame, Mongo mongo){
		this.frame = frame;
		this.mongo = mongo;
	}
	
	// Metodo que vai criar URL para a conex�o ao Sybase com o respectivo IP do servidor e a base de dados Sybase
	
	public void main() {
		
		frame.getIPButtonMySql().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				DB_URL = "jdbc:mysql://" + frame.getIPText().getText() + ":3306/db_mysql_origem";
				start();
			}
		});
		
		frame.getFrequencyButtonMySql().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				interrupt();
				
			}
		});
	}
	
	@Override
	public void run() {
		
		while(true){
			
			Connect();
			
    		try {
    			Thread.sleep(frame.getTimerMySql());
			} catch (InterruptedException a) {
				// TODO Auto-generated catch block
				a.printStackTrace();
			}
			
		}
	}
	
	// Metodo para efetuar a conex�o ao Sybase
	
	public void Connect(){
		
	    try {
	    	if(!connect){
				
		        Class.forName(JDBC_DRIVER);
	
		        System.out.println("Connecting to database...");
		        conn = DriverManager.getConnection(DB_URL, USER, PASS);

		        connect = true;
		        
		        stmt = conn.createStatement();
		        
				selectTemp();
				selectLumi();
	    	}
	    	
	    	else{
	    		
	    		stmt = conn.createStatement();
	    		
	    		addToMySql();
	        
	        	selectTemp();
	        	selectLumi();
	    	}
	        stmt.close();
//	        conn.close();
	    } catch (SQLException se) {
	        se.printStackTrace();
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {

	    }
	}	
	
	/* Metodo para inserir dados no sybase na tabela HumidadeTemperatura por cada dos inserido 
	com sucesso e inserido na cole��o BackUp do MongoDB */
	
	public void addToMySql(){
		
        String sql;
        String sql2;
        
        if(mongo.getConnect() == true){    
        	
			MongoCursor<Document> cursor = (MongoCursor<Document>) mongo.getTL().find().iterator();
			
	    	while(cursor.hasNext()) {
	    	    
	    		JSONParser parser = new JSONParser();
	    		JSONObject json = null;
				try {
					json = (JSONObject) parser.parse(cursor.next().toJson().toString());
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	
	    		Timestamp date = Timestamp.valueOf(json.get("date").toString());
	    		Double temperatura = null;
	    		Long cell = null;
	    		if(json.get("temperature") != null)
	    			temperatura = (Double) json.get("temperature");
	    		if(json.get("cell") != null)
	    			cell = (Long) json.get("cell");
	    		
	    		mongo.getModelTL().clear();
	    		sql = "insert into medicoestemperatura values (1, " + temperatura + ", '" + date + "')";
		        sql2 = "insert into medicoesluminosidade values (1, " + cell + ", '" + date + "')";
		       // System.out.println(sql);
		        try {
		        	if(temperatura != null)
		        		stmt.execute(sql);
		        	if(cell != null)
		        		stmt.execute(sql2);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	       	}
	        
	    	mongo.getTL().deleteMany(new Document());
	    	
	    	mongo.getModelTL().clear();
        }
	}
	
	// Metodo que efetua o select a tabela temp do sensor para ser possivel visualizar na frame
	
	public void selectTemp(){
		
        String sql;
        ResultSet rs = null;
    	        
        sql = "select * from medicoestemperatura";
        try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        model.clear();
        
        try {
			while (rs.next()) {
			    String data = rs.getString("DataHoraMedicao");
			    Double temperatura = rs.getDouble("ValorMedicaoTemperatura");
			    Integer id = rs.getInt("IDMedicao");
			    
			    model.addElement("Temperatura -> " + id + " | " + temperatura + " | " + data);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// Metodo que efetua o select a tabela lumi do sensor para ser possivel visualizar na frame
	
		public void selectLumi(){
			
	        String sql;
	        ResultSet rs = null;
	    	        
	        sql = "select * from medicoesluminosidade";
	        try {
				rs = stmt.executeQuery(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        try {
				while (rs.next()) {
				    String data = rs.getString("DataHoraMedicao");
				    Integer cell = rs.getInt("ValorMedicaoLuminosidade");
				    Integer id = rs.getInt("IDMedicao");
				    
				    model.addElement("Luminosidade -> " + id + " | " + cell + " | " + data);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	        list = new JList<>(model);
	        frame.getScrollPaneMySql().setViewportView(list);
		}
}
